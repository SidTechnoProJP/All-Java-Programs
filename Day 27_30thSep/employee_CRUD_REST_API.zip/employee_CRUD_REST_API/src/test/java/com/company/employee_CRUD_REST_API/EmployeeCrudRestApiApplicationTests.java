package com.company.employee_CRUD_REST_API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
