package com.company.employee_CRUD_REST_API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCrudRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudRestApiApplication.class, args);
	}

}
