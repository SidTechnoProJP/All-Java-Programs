package cric.champs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChampsApplicationTests {

	@Test
	void contextLoads() {
	}

}
