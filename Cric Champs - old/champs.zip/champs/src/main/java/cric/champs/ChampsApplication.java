package cric.champs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChampsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChampsApplication.class, args);
	}

}
