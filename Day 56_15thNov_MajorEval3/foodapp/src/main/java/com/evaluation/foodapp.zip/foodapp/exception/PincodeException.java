package com.evaluation.foodapp.exception;

public class PincodeException extends Exception {

    public PincodeException() {
        // TODO Auto-generated constructor stub
    }

    public PincodeException(String message) {
        // TODO Auto-generated constructor stub
        super(message);
    }

}
