package com.evaluation.foodapp.exception;

public class LatLongException extends Exception {

	public LatLongException() {
            // TODO Auto-generated constructor stub
        }

	public LatLongException(String message) {
            // TODO Auto-generated constructor stub
            super(message);
        }
}
