package com.evaluation.foodapp.model;

public class Filter {
    private String category;
    private String item;
    private String basePrice;
    private String topPrice;
}
