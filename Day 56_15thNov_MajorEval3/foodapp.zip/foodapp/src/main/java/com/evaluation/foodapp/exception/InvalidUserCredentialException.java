package com.evaluation.foodapp.exception;

public class InvalidUserCredentialException extends Exception {
    public InvalidUserCredentialException(String msg) {
        super(msg);
    }
}

