package com.evaluation.foodapp.service;

import com.evaluation.foodapp.exception.AdminException;
import com.evaluation.foodapp.model.Admin;

public interface AdminService {

	public String createNewAdmin() throws AdminException;

}
