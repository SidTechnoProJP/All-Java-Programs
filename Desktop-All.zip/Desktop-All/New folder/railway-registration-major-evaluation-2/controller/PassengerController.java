package com.railway.registration.controller;

import com.railway.registration.model.PassengerDetails;
import com.railway.registration.model.SeatType;
import com.railway.registration.model.TrainDetails;
import com.railway.registration.exception.CustomException;
import com.railway.registration.service.PassengerService;
import com.railway.registration.service.PassengerServiceImpl;
import com.railway.registration.service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
public class PassengerController {

    @Autowired
    PassengerService passengerService;
    @Autowired
    PassengerServiceImpl passengerServiceImpl;

    @GetMapping("/findtrain/{source}/{destination}")
    ResponseEntity<List<TrainDetails>> getTrain(@PathVariable String source, @PathVariable String destination) {
        try {
            return ResponseEntity.of(Optional.of(passengerServiceImpl.findAllTrain(source, destination)));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        } catch (CustomException e) {
            throw new RuntimeException(e);
        }
    }

    @PostMapping("/bookticket/{numberOfPassengers}/{trainNumber}/{dateOfTravelling}/{seatType}")
    ResponseEntity<String> bookTicket(@PathVariable int numberOfSeatsBooked, @PathVariable long trainNumber,
                                      @PathVariable Date dateOfTravel, @PathVariable SeatType seatType, @RequestBody List<PassengerDetails> passengerList) {
        try {
            return ResponseEntity.of(Optional.of(passengerServiceImpl.ticketBooking(numberOfSeatsBooked,  trainNumber, dateOfTravel, seatType,passengerList)));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @DeleteMapping("/cancelticket/{tickedId}")
    ResponseEntity<String> bookTicket(@PathVariable int ticketId){
    try {
        return ResponseEntity.of(Optional.of(passengerServiceImpl.cancelTicketBooking(ticketId)));
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
    }
}
