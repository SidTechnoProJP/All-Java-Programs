package com.railway.registration.exception;

public class CustomException extends Throwable {
    public CustomException(String s) {
    }
}
