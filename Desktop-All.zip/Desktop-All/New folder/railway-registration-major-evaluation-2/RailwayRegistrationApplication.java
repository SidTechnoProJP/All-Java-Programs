package com.railway.registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailwayRegistrationApplication.class, args);
	}

}
