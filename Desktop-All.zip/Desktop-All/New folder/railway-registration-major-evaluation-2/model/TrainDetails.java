package com.railway.registration.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

//class containing train details

public class TrainDetails {
    private List<Date> trainTravelDate = new ArrayList<>();
    private int trainNumber;
    private String trainName;
    private String trainSource;
    private String trainDestination;
    private int acSeatPrice;
    private int genSeatPrice;
}
