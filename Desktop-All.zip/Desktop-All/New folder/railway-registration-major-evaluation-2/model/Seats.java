package com.railway.registration.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor

//class containing seat details

public class Seats {
    private int trainNumber;
    private int availableAcSeats;
    private int bookedAcSeats;
    private int availableGenSeats;
    private int bookedGenSeats;
    private int availableAcBooked;
    private int availableAcWaiting;
    private int availableGenBooked;
    private int availableGenWaiting;

    private int bookedAcWaiting;
    private int bookedGenWaiting;

    private Date travelDate;

}
