package com.railway.registration.model;

public enum BookingStatus {
    CONFIRMED, WAITING
}
