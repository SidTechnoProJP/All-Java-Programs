package com.railway.registration.model;

public enum SeatType {
    AC, GENERAL
}
