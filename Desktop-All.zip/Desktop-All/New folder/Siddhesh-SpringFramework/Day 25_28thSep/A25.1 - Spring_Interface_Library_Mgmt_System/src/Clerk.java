import java.util.List;

public class Clerk implements User, User2{

    @Override
    public String searchBook(List<String> booksList, String bookName) {
        return null;
    }



    @Override
    public void loanHistory() {

    }

    @Override
    public void addBorrower() {

    }
}
