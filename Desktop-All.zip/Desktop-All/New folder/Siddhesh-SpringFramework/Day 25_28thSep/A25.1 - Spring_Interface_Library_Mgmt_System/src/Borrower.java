import java.util.List;

public class Borrower implements User{
    int borrowerId;
    String borrowerName;


    @Override
    public String searchBook(List<String> booksList, String bookName) {
        return null;
    }


    @Override
    public void loanHistory() {

    }
}
