public interface User2 {
    void addBorrower();
}
