package com.mydemo;

import com.sun.xml.internal.ws.api.ha.StickyFeature;

public interface Phone {
    public String getOS();
    public String getBrand();
}
