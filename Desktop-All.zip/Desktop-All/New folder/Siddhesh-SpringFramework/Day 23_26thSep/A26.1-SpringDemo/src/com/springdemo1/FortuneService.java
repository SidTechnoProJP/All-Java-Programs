package com.springdemo1;

public interface FortuneService {
    public String getFortune();
}
