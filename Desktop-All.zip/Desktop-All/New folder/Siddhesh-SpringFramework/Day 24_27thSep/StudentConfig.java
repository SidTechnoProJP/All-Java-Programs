import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("sep27")
public class StudentConfig {
//    @Bean
//    public Student student() {
//        return new Student();
//    }

    //
//    @Bean
//    public Course course() {
//        return new Course();
//    }

}