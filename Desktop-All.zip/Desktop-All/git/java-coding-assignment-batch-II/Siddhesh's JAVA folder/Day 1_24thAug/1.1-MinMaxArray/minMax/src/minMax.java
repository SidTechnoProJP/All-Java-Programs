import java.util.*;

public class minMax {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.println("Enter the array size: ");
        int size = s.nextInt();

        int [] array = new int[size];
        System.out.println("Enter the "+size+" elements: ");
        for (int i=0; i< array.length;i++){
            array[i] = s.nextInt();
        }

        int max = Arrays.stream(array).max().getAsInt();
        int min = Arrays.stream(array).min().getAsInt();

        System.out.println("The max value is: "+max);
        System.out.println("The min value is: "+min);

    }
}
