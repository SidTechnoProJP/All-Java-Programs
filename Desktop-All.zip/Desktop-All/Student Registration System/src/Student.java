import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student {

    Scanner sc = new Scanner(System.in);

    private String usn;
    private String name, elective1, elective2;

    public int getUsn() {
        return usn;
    }

    public void setUsn(int usn) {
        this.usn = usn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public void selectElective1() throws IOException {
        System.out.println("The Electives in are");
        System.out.println(department.showElective1());
        System.out.print("Enter the subject code: ");
        int subCode = sc.nextInt();
        System.out.println(studentList +" selected Elective : "+department.getElective1().get(subCode));
    }

    public void selectElective2()
    {
        System.out.println("The Electives in are");
        System.out.println(department.showElective2());
        System.out.print("Enter the subject code: ");
        int subCode = sc.nextInt();
        System.out.println("Your selected Elective is: "+department.getElective2().get(subCode));
    }
}
