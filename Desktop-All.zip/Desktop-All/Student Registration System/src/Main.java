import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
       Department dept = new Department();
       Student student = new Student();
       //dept.addElective1();

Department department = new Department();
Student student = new Student();



        student.selectElective1();
        student.selectElective2();

        Map<String, Student>  

        System.out.println("Welcome to SRS!")

    }
}