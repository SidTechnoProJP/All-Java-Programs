import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Department {

    private Map<Integer, String> elective1 = new HashMap<>();
    private Map<Integer, String> elective2 = new HashMap<>();


    public HashMap<Integer, String> getElective1() {
        return elective1;
    }

    public HashMap<Integer, String> getElective2() {
        return elective2;
    }

    public HashMap<Integer, String> showElective1()
    {
        elective1.put(1001,"Data Structures");
        elective1.put(1221,"Operating System");
        elective1.put(1351,"Computer Networks");

        return elective1;
    }
    public HashMap<Integer, String> showElective2()
    {
        elective2.put(2551,"Fluid Mechanics");
        elective2.put(1221,"Thermodynamics");
        elective2.put(1351,"Heat Transfer");

        return elective2;
    }
}
