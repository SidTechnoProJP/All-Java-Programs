//Assignment 3 & 4
import java.util.*;
import java.io.*;

public class Comstr{
	public static void main(String args[]){
		String string1 = new String("hello");
		String string2 = new String("world");
		String string3 = new String("hey");
		String string4 = new String("Hey");

		System.out.println("Comparing String 1: " + string1 + " and String 2: " + string2 + " : " + string1.equals(string2));
		System.out.println("Comparing String 3: " + string3 + " and String 4: " + string4 + " : " + string3.equals(string4));
		System.out.println("Comparing String 3: " + string3 + " and String 4: " + string4 + " : " + string3.equalsIgnoreCase(string4));
	}
}