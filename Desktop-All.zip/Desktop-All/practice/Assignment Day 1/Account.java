//Assignment 6 - Banking Application

import java.util.*;
import java.io.*;

class Account{

	public static void main(String args[]){
		Account acc = new Account();
		// acc.OpenAccount();
		//acc.Withdraw();
		//acc.Deposit();
		//acc.MonthlyInterest();
		// int choice;
		Scanner sc = new Scanner(System.in);

		while(true) {
 
            int choice; //Creating menu
            System.out.println("1. Create Account \n");
            System.out.println("2. Withdraw \n");
            System.out.println("3. Deposit \n");
            System.out.println("4. Interest Rate\n");
            System.out.println("5. Exit\n");

 
            //Asking user to make choice
            System.out.println("Make your choice: ");
            choice = sc.nextInt();
 
            //Creating switch case branch
            switch (choice) {
            case 1: 
            	acc.OpenAccount();
            	break;
            case 2:
            	acc.Withdraw();
            	break;
            case 3:
            	acc.Deposit();
            	break;
            case 4:
            	acc.MonthlyInterest();
            	break;
            case 5:
            	return;
     
            }

		}
	}

	private int id;
	private double balance;
	private double annualInterestRate;
	private Date dateCreated;

	Scanner sc = new Scanner(System.in);  

	public void OpenAccount(){
		System.out.println("Enter Account Id: ");
		id=sc.nextInt();

		System.out.println("Enter Balance: ");
		balance=sc.nextDouble();

		System.out.println("Enter Annual Interest Rate: ");
		annualInterestRate=sc.nextDouble();

		System.out.println("Date Created: "+dateCreated.toString());
	}

	public void Withdraw(){

		long wd;
		System.out.println("Enter Account Id: ");
		id=sc.nextInt();

		System.out.println("Available Balance: " + this.getBalance());

		System.out.println("Enter Withdrawal Amount: ");
		wd=sc.nextLong();

		if (balance>=wd){
			balance = balance - wd;
			System.out.println("Balance after withdrawal: " + balance);
		}

		else{
			System.out.println("Insufficient Funds!");
		}
	}

	public void Deposit(){
		long dp;
		System.out.println("Enter Account Id: ");
		id=sc.nextInt();

		System.out.println("Available Balance: " + balance);

		System.out.println("Enter Deposit Amount: ");
		dp=sc.nextLong();

		balance = balance + dp;

		System.out.println("Balance after deposit: " + balance);

	}

	public void MonthlyInterest(){
		System.out.println("Your Monthly Interest Rate is: " + ((balance*annualInterestRate/100)/12));
	}

	//without argument constructor
	Account(){
		dateCreated = new Date();
	}

	//with argument constructor
	Account(int id, double balance){
		this.id = id;
		this.balance = balance;
	}

	//getter accessor for id
	public int getId(){
		return id;
	}

	//setter mutator for id
	private void setId(int id){
		this.id = id;
	}

	//getter accessor for balance
	public double getBalance(){
		return balance;
	}

	//setter mutator for balance
	public void setBalance(){
		this.balance = balance;
	}

	//getter accessor for annual interest rate
	public double annualInterestRate(){
		return annualInterestRate;
	}

	//setter mutator for annual interest rate
	public void setAnnualInterestRate(){
		this.annualInterestRate = annualInterestRate;
	}

	//getter accessor for Date Created
	public Date dateCreated(){
		return dateCreated; 
	}

}
