//Assignment 5 - If the substring matches with the end of a string

import java.util.*;
import java.io.*;

public class Compstr{

	public static void main(String args[]){

		Compstr s = new Compstr();

		String string1 = new String("Hi over there Hi");
		String string2 = new String("Hello world");
		String string3 = new String("educated");
		String string4 = new String("madam");

		System.out.println("String 1: " + string1);
		System.out.println("String 2: " + string2);
		System.out.println("String 3: " + string3);
		System.out.println("String 4: " + string4);

		System.out.println();

		System.out.println("New String 1 is : " +s.notMatch(string1));
		System.out.println("New String 2 is : " +s.notMatch(string2));
		System.out.println("New String 3 is : " +s.notMatch(string3));
		System.out.println("New String 4 is : " +s.notMatch(string4));
	};

	public String notMatch(String str){
		int len = str.length();
		if (len==2)
			return "";

		if (len < 2)
			return str;

		else{
			if(str.substring(0,2).equals(str.substring(len-2, len)))
				return str.substring(2,len);
			    else return str;
			}
	}
}