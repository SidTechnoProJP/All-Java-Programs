//Assignment 6 - Banking Application

import java.util.*;
import java.io.*;

class Account{

	private int id;
	private double balance;
	private double annualInterestRate;
	private Date dateCreated;

	Scanner sc = new Scanner(System.in);  

	public void OpenAccount{
		System.out.println("Enter Account Id: ");
		id=sc.next();

		System.out.println("Enter Balance: ");
		balance=sc.next();

		System.out.println("Enter Annual Interest Rate: ");
		annualInterestRate=sc.next();

		System.out.println("Date Created: "+dateCreated.toString());
	}

	public void Withdraw{

		long wd;
		System.out.println("Enter Account Id: ");
		id=sc.next();

		System.out.println("Available Balance: " + balance);

		System.out.println("Enter Withdrawal Amount: ");
		wd=sc.nextLong();

		if (balance>=wd){
			balance = balance - wd;
			System.out.println("Balance after withdrawal: " + balance);
		}

		else{
			System.out.println("Insufficient Funds!");
		}
	}

	public void Deposit{
		long dp;
		System.out.println("Enter Account Id: ");
		id=sc.next();

		System.out.println("Available Balance: " + balance);

		System.out.println("Enter Deposit Amount: ");
		dp=sc.next();

		balance = balance + dp;

		System.out.println("Balance after deposit: " + balance);

	}

	public void getMonthlyInterest(){
		System.out.println("Your Monthly Interest Rate is: " + ((balance*annualInterestRate/12)*100));
	}

	//without argument constructor
	Account(){
		dateCreated = new Date();
	}

	//with argument constructor
	Account(int id, double balance){
		this.id = id;
		this balance = balance;
	}

	//getter accessor for id
	public int getId(){
		return id;
	}

	//setter mutator for id
	private void setId(int id){
		this.id = id;
	}

	//getter accessor for balance
	public double getBalance(){
		return balance;
	}

	//setter mutator for balance
	public void setBalance(){
		this.balance = balance;
	}

	//getter accessor for annual interest rate
	public double annualInterestRate(){
		return annualInterestRate;
	}

	//setter mutator for annual interest rate
	public void setAnnualInterestRate(){
		this.annualInterestRate = annualInterestRate;
	}

	//getter accessor for Date Created
	public Date dateCreated(){
		return dateCreated; 
	}

	 
}

	









/*	public void setId(int newId){
		id = newId;
	}

	public void setId(int newId){
		this.id = id;
	}

	public void setBalance(double newBalance){
		balance = newBalance;
	}

	public void set balance(double balance){
		this.balance = balance;
	}

	// public void setAnnualInterestRate(double newAnnualInterestRate){
	// 	annualInterestRate = newAnnualInterestRate;
	// }

	// public void set annualInterestRate(double annualInterestRate){
	// 	this.annualInterestRate = annualInterestRate;
	// }

	// public void setDateCreated(int newDateCreated){
	// 	dateCreated = newDateCreated;
	}

}*/