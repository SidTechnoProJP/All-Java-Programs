class Student {
    int rollno, age;
    String name, course;
    Student(){
        rollno = 0;
        age = 0;
        name = null;
        course = null;
    }
    Student(int rno, int a, String n, String c){
        rollno = rn;
        age = a;

    }

}
