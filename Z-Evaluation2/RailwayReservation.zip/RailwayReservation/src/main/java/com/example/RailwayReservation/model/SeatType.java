package com.example.RailwayReservation.model;

public enum SeatType {
    AC,
    GN
}
