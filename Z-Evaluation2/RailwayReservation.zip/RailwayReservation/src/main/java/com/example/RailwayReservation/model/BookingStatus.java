package com.example.RailwayReservation.model;

public enum BookingStatus {
    CONFIRMED,
    WAITING
}
