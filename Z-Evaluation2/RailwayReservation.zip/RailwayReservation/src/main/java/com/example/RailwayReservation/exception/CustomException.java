package com.example.RailwayReservation.exception;

public class CustomException extends Exception{
    CustomException(){}

    public CustomException(String s){
        super(s);

    }
}
