package com.springboot.jdbcdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
