package foodapp.exception;

public class UpdateFailedException extends Exception{
    public UpdateFailedException(String message) {
        super(message);
    }
}
