package foodapp.exception;

public class SignupException extends Exception {
    public SignupException(String message) {
        super(message);
    }
}
