package foodapp.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import foodapp.exception.SessionIdExpiredException;
import foodapp.exception.UpdateFailedException;
import foodapp.model.Menu;
import foodapp.service.restaurant.MenuInterface;

import java.io.IOException;
import java.util.Optional;

@RestController
@RequestMapping("/menu")
public class MenuController {
    @Autowired
    private MenuInterface menuInterface;

    @PostMapping("/add")
    public ResponseEntity<String> addMenu(@ModelAttribute Menu menu, @RequestParam MultipartFile dishPhoto) throws SessionIdExpiredException, IOException {
        return ResponseEntity.of(Optional.of(menuInterface.addMenu(menu, dishPhoto)));
    }

    @PatchMapping("/update")
    public ResponseEntity<String> changeDescription(@RequestParam String itemName, @RequestParam String categoryName,
                                                    @RequestParam String description) throws SessionIdExpiredException, UpdateFailedException {
        return ResponseEntity.of(Optional.of(menuInterface.changeDescription(itemName, categoryName, description)));
    }

    @PatchMapping("/updatePhoto")
    public ResponseEntity<String> changeDishPhoto(@RequestParam String itemName, @RequestParam String categoryName,
                                                  @RequestParam MultipartFile dishPhoto) throws SessionIdExpiredException, UpdateFailedException, IOException {
        return ResponseEntity.of(Optional.of(menuInterface.changeDishPhoto(itemName, categoryName, dishPhoto)));
    }

    @PatchMapping("/updateDishPrice")
    public ResponseEntity<String> changeDishPrice(@RequestParam String itemName, @RequestParam String categoryName,
                                                  @RequestParam int itemPrice) throws SessionIdExpiredException, UpdateFailedException {
        return ResponseEntity.of(Optional.of(menuInterface.changeDishPrice(itemName, categoryName, itemPrice)));
    }

    @PatchMapping("/updateCategory")
    public ResponseEntity<String> changeCategory(@RequestParam String itemName, @RequestParam String oldCategoryName,
                                                 @RequestParam String newCategoryName) throws SessionIdExpiredException, UpdateFailedException {
        return ResponseEntity.of(Optional.of(menuInterface.changeCategory(itemName, oldCategoryName, newCategoryName)));
    }

    @DeleteMapping("/remove")
    public ResponseEntity<String> removeMenu(@RequestParam String itemName, @RequestParam String categoryName) throws UpdateFailedException, SessionIdExpiredException {
        return ResponseEntity.of(Optional.of(menuInterface.removeMenu(itemName, categoryName)));
    }

    @DeleteMapping("/removeDishPhoto")
    public ResponseEntity<String> deleteOldPhoto(@RequestParam String itemName, @RequestParam String categoryName) throws IOException, SessionIdExpiredException {
        return ResponseEntity.of(Optional.of(menuInterface.deleteOldPhoto(itemName, categoryName)));
    }

}
