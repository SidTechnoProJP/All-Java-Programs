package foodapp.service;

public enum PaymentTypes {
    CREDITCARD ,DEBITCARD,CASHONDELIVARY,UPI,NETBANKING
}
