package foodapp.service;

public enum AccountStatus {
    VERIFIED, NOTVERIFIED
}
