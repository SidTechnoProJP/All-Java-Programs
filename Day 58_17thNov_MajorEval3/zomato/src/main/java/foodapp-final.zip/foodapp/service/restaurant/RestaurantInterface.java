package foodapp.service.restaurant;

import org.springframework.web.multipart.MultipartFile;
import foodapp.exception.InvalidTimeException;
import foodapp.exception.SessionIdExpiredException;
import foodapp.exception.UpdateFailedException;
import foodapp.entity.Restaurants;

import java.io.IOException;
import java.time.LocalTime;

public interface RestaurantInterface {

    String Login(String restaurantId) throws SessionIdExpiredException;

    String register(String restaurantId, String restaurantName, String restaurantAddress, LocalTime open, LocalTime close, String closedDay, MultipartFile photo) throws IOException, SessionIdExpiredException;

    Restaurants viewRestaurantDetails() throws SessionIdExpiredException;

    byte[] viewRestaurantPhoto() throws SessionIdExpiredException, IOException;
    String changeRestaurantPhoto(MultipartFile photo) throws IOException, SessionIdExpiredException, UpdateFailedException;

    String changeOpenTime(int openHour, int openMinutes) throws SessionIdExpiredException, InvalidTimeException;

    String changeCloseTime(int closeHour, int closeMinutes) throws SessionIdExpiredException, InvalidTimeException;

    String changeCloseDay(String day) throws SessionIdExpiredException, UpdateFailedException;

    String changeRestaurantAddress(String restaurantAddress) throws SessionIdExpiredException, UpdateFailedException;

    String changeRestaurantName(String restaurantName) throws SessionIdExpiredException, UpdateFailedException;

    String deleteRestaurantPhoto() throws SessionIdExpiredException, IOException;

    String deleteRestaurant() throws SessionIdExpiredException;

    String logout() throws SessionIdExpiredException;
}
