package IOSevaluationQuestion;

public class HospitalApplication {
    public static void main(String[] args) {
        HospitalInterface hospital = new Hospital();
        hospital.callHospital();
    }
}
