package IOSevaluationQuestion;

public enum SelectAdmitOrOpd {
    ADMIT,OPD
}
