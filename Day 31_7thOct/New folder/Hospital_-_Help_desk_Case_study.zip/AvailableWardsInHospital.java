package IOSevaluationQuestion;

enum AvailableWardsInHospital {
}
