package IOSevaluationQuestion;

public enum Gender {
    MALE,FEMALE,OTHERS
}

