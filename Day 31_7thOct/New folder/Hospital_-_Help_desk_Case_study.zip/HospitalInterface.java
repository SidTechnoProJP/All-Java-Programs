package IOSevaluationQuestion;

public interface HospitalInterface {
    void callHospital();
    void addVariousDepartmentInHospital();

    void addVariousWardsInHospital();
}
