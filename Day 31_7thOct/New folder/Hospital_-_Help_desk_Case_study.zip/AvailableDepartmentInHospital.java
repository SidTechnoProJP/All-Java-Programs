package IOSevaluationQuestion;

public enum AvailableDepartmentInHospital {
    DPT01,DPT02,DPT03,DPT04
}
