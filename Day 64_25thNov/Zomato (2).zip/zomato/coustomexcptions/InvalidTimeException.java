package zomatomodified.zomato.coustomexcptions;

public class InvalidTimeException extends Exception{
    public InvalidTimeException(String message) {
        super(message);
    }
}
