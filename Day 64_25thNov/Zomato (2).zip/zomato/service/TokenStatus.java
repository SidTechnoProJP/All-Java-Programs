package zomatomodified.zomato.service;

public enum TokenStatus {
    ACTIVE, EXPIRED
}

