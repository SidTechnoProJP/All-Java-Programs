package foodapp.customexceptions;

public class SignOutException extends Exception {
    public SignOutException(String message) {
        super(message);
    }
}
