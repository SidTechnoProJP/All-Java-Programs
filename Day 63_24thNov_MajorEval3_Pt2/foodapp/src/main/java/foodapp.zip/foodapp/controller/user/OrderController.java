package foodapp.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import foodapp.customexceptions.InvalidCardNumberException;
import foodapp.model.MyOrders;
import foodapp.service.user.OrderInterface;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/user/order")
public class OrderController {


    /**
     * Order Controller
     */

    @Autowired
    private OrderInterface orderInterface;

    @PostMapping("/makeOrder")
    public ResponseEntity<List<MyOrders>> addOrders(@RequestHeader String restaurantId, @RequestBody Map<String, Map<String, Integer>> orders,
                                                    @RequestHeader String paymentType) {
        return ResponseEntity.of(Optional.of(orderInterface.addOrders(restaurantId, orders, paymentType)));
    }

    @PostMapping("/makePayment")
    public ResponseEntity<String > makePayment(@RequestPart String restaurantId,@RequestPart String orderId,
                                               @RequestHeader String paymentType,@RequestHeader(required = false) Long cardNumber) throws InvalidCardNumberException {
        return ResponseEntity.of(Optional.of(orderInterface.makePayment(restaurantId,orderId,paymentType,cardNumber)));
    }
}
