package foodapp.controller.restaurant;

import foodapp.entity.Categories;
import foodapp.model.Menu;
import foodapp.model.RestaurantCategory;
import foodapp.service.admin.MenuCategoryInterface;
import foodapp.service.admin.MenuInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/restaurant")
public class MenuCategoryController {

    @Autowired
    private MenuCategoryInterface menuCategoryInterface;

    @Autowired
    private MenuInterface menuInterface;

    @PostMapping("/addCategory")
    public ResponseEntity<String> addMenu(@RequestBody List<String> categoryId, @RequestHeader String restaurantId) {
        return ResponseEntity.of(Optional.of(menuCategoryInterface.addMenu(categoryId, restaurantId)));
    }

    @DeleteMapping("/deleteMenu")
    public ResponseEntity<String> removeMenu(@RequestParam String restaurantId) {
        return ResponseEntity.of(Optional.of(menuCategoryInterface.deleteMenu(restaurantId)));
    }

    @GetMapping("/showAllCategories")
    public ResponseEntity<List<Categories>> viewAllCategories() {
        return ResponseEntity.of(Optional.of(menuCategoryInterface.viewAllCategories()));
    }

    @GetMapping("/showCategory")
    public ResponseEntity<List<RestaurantCategory>> viewMenu(@RequestParam String restaurantId) {
        return ResponseEntity.of(Optional.of(menuCategoryInterface.viewMenu(restaurantId)));
    }

    @DeleteMapping("/deleteCategory")
    public ResponseEntity<String> removeCategory(@RequestParam String restaurantId, @RequestParam String categoryId) {
        return ResponseEntity.of(Optional.of(menuCategoryInterface.deleteCategory(categoryId, restaurantId)));
    }

    @PostMapping("/addMenu")
    public ResponseEntity<String> addMenus(@ModelAttribute Menu menu){
        return ResponseEntity.of(Optional.of(menuInterface.addMenu(menu)));
    }

}
