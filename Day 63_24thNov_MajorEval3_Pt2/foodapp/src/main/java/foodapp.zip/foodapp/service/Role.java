package foodapp.service;

public enum Role {
    ADMIN,CUSTOMER
}
