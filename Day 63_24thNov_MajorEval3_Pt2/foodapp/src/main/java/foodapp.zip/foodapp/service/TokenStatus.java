package foodapp.service;

public enum TokenStatus {
    ACTIVE, EXPIRED
}

