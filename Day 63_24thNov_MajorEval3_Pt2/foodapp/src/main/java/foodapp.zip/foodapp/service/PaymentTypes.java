package foodapp.service;

public enum PaymentTypes {
    CREDITCARD ,DEBITCARD,UPI,NETBANKING
}
