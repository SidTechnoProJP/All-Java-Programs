package foodapp.service;

public enum OrderStatus {
    CONFIRMED,REJECTED,PAYMENTPENDING
}
