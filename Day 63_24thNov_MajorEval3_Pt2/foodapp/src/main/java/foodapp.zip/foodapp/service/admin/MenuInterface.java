package foodapp.service.admin;

import foodapp.model.Menu;

public interface MenuInterface {

    String addMenu(Menu menu);

}
