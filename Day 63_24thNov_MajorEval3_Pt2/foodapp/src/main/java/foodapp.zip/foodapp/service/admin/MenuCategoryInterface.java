package foodapp.service.admin;

import foodapp.entity.Categories;
import foodapp.model.RestaurantCategory;

import java.util.List;

public interface MenuCategoryInterface {

    String addMenu(List<String> categoryId, String restaurantId);

    String deleteMenu(String restaurantId);

    String deleteCategory(String categoryId, String restaurantId);

    List<RestaurantCategory> viewMenu(String restaurantId);

    List<Categories> viewAllCategories();
}
