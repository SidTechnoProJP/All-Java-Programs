package com.bookmyshow;

public enum Genre {
    ACTION, COMEDY, HORROR;
}
