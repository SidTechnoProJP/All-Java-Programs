package com.bookmyshow;

public enum PaymentStatus {
    PAID, UNPAID
}
