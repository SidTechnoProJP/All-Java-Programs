package com.bookmyshow;

public enum PaymentMethod {
    CASH, CARD
}
