package com.bookmyshow;

public class FrontDeskOfficer extends User{

    public FrontDeskOfficer(String name) {
        super(name);
    }

    public void createBooking(){}
    public void cancelBooking(){}

}

