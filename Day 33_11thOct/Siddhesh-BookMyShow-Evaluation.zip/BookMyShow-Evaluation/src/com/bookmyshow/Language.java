package com.bookmyshow;
public enum Language {
	HINDI, ENGLISH;
}
