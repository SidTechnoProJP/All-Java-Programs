package cric.champs.service;

public enum ExtraRunsType {
    wide, bye, noBall, legBye, penaltyRuns
}
