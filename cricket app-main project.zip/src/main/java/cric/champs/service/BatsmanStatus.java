package cric.champs.service;

public enum BatsmanStatus {
    OUT,NOTOUT
}
