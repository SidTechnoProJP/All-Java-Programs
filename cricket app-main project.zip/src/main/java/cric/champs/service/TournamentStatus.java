package cric.champs.service;

public enum TournamentStatus {
    UPCOMING, PROGRESS, COMPLETED, CANCELLED
}
