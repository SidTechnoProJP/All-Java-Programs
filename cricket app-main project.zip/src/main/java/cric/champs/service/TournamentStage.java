package cric.champs.service;

public enum TournamentStage {
    FINALS,SEMIFINALS
}
