package cric.champs.service;

public enum VersusStatus {
    WIN, LOSS, DRAW, CANCELLED,INNINGCOMPLETE
}
