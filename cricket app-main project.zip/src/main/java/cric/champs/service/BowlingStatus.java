package cric.champs.service;

public enum BowlingStatus {
    BOWLING,DONE
}
