package cric.champs.customexceptions;

public class SignupException extends Exception {
    public SignupException(String message) {
        super(message);
    }
}
