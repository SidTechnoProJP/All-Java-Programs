package cric.champs.customexceptions;

public class InvalidFieldException extends Exception{
    public InvalidFieldException(String message) {
        super(message);
    }
}
