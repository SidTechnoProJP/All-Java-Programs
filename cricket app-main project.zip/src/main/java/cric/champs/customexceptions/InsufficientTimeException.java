package cric.champs.customexceptions;

public class InsufficientTimeException extends Exception{
    public InsufficientTimeException(String message) {
        super(message);
    }
}
