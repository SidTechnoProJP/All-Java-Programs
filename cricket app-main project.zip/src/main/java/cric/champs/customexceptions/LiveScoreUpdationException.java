package cric.champs.customexceptions;

public class LiveScoreUpdationException extends Exception {
    public LiveScoreUpdationException(String message) {
        super(message);
    }
}
