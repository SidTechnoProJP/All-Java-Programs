package cric.champs.rate.rattingandfaqs;

import cric.champs.rate.model.HelpAndFAQs;

import java.util.List;

public interface HelpAndFAQsInterface {

    List<HelpAndFAQs> helpAndFAQs();

}
