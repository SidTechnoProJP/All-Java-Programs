package com.movieTicketBookingSystem.auth.model;

public enum OtpStatus {

    DELIVERED,FAILED
}