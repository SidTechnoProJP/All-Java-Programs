package com.movieTicketBookingSystem.auth.service;

import org.springframework.stereotype.Service;

@Service
public class TwilioOtpService {


    public TwilioOtpService() {
    }


}