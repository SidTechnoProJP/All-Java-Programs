package com.springboot.phoneotp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoneotpApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhoneotpApplication.class, args);
	}

}
