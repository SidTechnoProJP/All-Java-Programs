package com.srs.assignment;

public class Faculty {
    int facultyID;
    String facultyName;
    String deptName;

    Faculty(int facultyID, String facultyName, String deptName){
        this.facultyID = facultyID;
        this.facultyName = facultyName;
        this.deptName = deptName;
    }


}
