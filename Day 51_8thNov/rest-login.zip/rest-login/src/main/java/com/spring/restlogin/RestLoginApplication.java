package com.spring.restlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestLoginApplication.class, args);
	}

}
