package example.loginpage.coustomexception;

public class SignupException extends Exception {
    public SignupException(String msg) {
        super(msg);
    }
}
