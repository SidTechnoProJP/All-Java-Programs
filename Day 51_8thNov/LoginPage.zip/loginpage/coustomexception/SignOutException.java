package example.loginpage.coustomexception;

public class SignOutException extends Exception {
    public SignOutException(String message) {
        super(message);
    }
}
