package com.spring.restapilogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapiLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiLoginApplication.class, args);
	}

}
