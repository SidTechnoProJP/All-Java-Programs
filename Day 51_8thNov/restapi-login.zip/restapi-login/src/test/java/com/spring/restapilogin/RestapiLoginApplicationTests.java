package com.spring.restapilogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
