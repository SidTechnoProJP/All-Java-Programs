package com.foodapp;

public enum Provider {
	LOCAL, GOOGLE, FACEBOOK, GITHUB
}
