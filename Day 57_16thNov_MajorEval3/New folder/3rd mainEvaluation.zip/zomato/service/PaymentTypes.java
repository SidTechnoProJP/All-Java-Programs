package zomato.service;

public enum PaymentTypes {
    CREDITCARD ,DEBITCARD,CASHONDELIVARY,UPI,NETBANKING
}
