
public class GuestUser extends User {
	 public GuestUser(String name) {
	        super(name);
	    }

	    public void register(String username, String password){

	    }

}
