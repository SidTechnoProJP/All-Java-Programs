
public enum Language {
	HINDI, ENGLISH;

}
