
public enum Genre {
	ACTION, ROMANCE, COMEDY, HORROR;

}
