package com.foodyexpress.exception;

public class ItemException extends Exception {

	public ItemException() {
		// TODO Auto-generated constructor stub
	}

	public ItemException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
