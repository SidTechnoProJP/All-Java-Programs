package com.foodyexpress.exception;

public class LoginException extends Exception {

	public LoginException() {
		// TODO Auto-generated constructor stub
	}

	public LoginException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
