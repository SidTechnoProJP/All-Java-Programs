package zomatomodified.zomato.coustomexcptions;

public class OTPGenerateException extends Exception{
    public OTPGenerateException(String message) {
        super(message);
    }
}
