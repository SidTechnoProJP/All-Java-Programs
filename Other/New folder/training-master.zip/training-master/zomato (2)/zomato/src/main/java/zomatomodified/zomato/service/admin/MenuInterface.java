package zomatomodified.zomato.service.admin;

import zomatomodified.zomato.model.Menu;

public interface MenuInterface {

    String addMenu(Menu menu);

}
