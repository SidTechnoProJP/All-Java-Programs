package zomatomodified.zomato.service;

public enum OrderStatus {
    CONFIRMED,REJECTED,PAYMENTPENDING
}
