package zomatomodified.zomato.service;

public enum AccountStatus {
    VERIFIED, NOTVERIFIED
}
