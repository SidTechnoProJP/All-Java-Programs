package zomatomodified.zomato.service;

public enum Role {
    ADMIN,CUSTOMER
}
