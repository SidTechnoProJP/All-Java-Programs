package zomatomodified.zomato.service;

public enum PaymentTypes {
    CREDITCARD ,DEBITCARD,UPI,NETBANKING
}
