package zomatomodified.zomato.coustomexcptions;

public class SignupException extends Exception {
    public SignupException(String message) {
        super(message);
    }
}
