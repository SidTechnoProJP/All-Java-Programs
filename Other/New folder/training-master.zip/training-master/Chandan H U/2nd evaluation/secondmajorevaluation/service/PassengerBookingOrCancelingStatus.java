package example.secondmajorevaluation.service;

public enum PassengerBookingOrCancelingStatus {
    Booking,Cancelling
}
