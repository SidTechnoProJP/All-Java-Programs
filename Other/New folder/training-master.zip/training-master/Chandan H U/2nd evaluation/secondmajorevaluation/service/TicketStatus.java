package example.secondmajorevaluation.service;

public enum TicketStatus {
    Confirm,Waiting,Cancelled
}
