package September28;

import java.util.HashSet;
import java.util.Set;

public class LibraryStore {
    public static Set<String> titleOfBook = new HashSet<>();


}
