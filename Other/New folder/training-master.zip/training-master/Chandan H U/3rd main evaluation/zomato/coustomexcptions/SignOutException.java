package zomato.coustomexcptions;

public class SignOutException extends Exception {
    public SignOutException(String message) {
        super(message);
    }
}
