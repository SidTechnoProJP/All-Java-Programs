package zomato.service;

public enum AccountStatus {
    VERIFIED, NOTVERIFIED
}
