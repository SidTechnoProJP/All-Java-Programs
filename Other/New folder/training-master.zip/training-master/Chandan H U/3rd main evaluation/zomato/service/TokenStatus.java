package zomato.service;

public enum TokenStatus {
    ACTIVE,EXPIRED
}
