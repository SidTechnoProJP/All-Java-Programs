package September26;

public class Books {
    private String bookAuthor, bookName;
    double bookPrice;

    public void setBookAuthor(String bookAuthor) {this.bookAuthor = bookAuthor;}

    public void setBookName(String bookName) {this.bookName = bookName;}

    public void setBookPrice(double bookPrice) {this.bookPrice = bookPrice;}

    public String getBookAuthor() {return bookAuthor;}

    public String getBookName() {return bookName;}

    public double getBookPrice() {return bookPrice;}

}
