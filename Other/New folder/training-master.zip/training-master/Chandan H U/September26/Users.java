package September26;

public class Users {
    private String bookNumber;

    public void setBookNumber(String bookNumber) {
        this.bookNumber = bookNumber;
    }

    public String getBookNumber() {
        return bookNumber;
    }
}
