package September26;

public interface Coach {
    public String getDailyWorkout();
}
