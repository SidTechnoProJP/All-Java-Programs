package assignment3;

public class DetialsOfEmployee {
    public static void main(String agrs[]){

    }
}
