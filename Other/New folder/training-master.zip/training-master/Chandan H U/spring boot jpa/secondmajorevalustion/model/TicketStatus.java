package secondmajorevalustion.model;

public enum TicketStatus {
    Confirmed,Waiting
}
