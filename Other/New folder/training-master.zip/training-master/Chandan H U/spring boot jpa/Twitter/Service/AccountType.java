package Twitter.Service;

public enum AccountType {
    Public,Private
}
