package Twitter.Service;

public enum GenderAvailable {
    Male,Female,Other
}
