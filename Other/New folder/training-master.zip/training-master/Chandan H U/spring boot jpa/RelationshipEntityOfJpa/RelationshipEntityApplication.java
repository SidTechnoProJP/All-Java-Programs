package RelationshipEntityOfJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationshipEntityApplication {
    public static void main(String[] args) {
        SpringApplication.run(RelationshipEntityApplication.class,args);
    }
}
