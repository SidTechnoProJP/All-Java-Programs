package FirstEavluation;

public interface SystemInterface {
    void displayRunningCinemas();
}
