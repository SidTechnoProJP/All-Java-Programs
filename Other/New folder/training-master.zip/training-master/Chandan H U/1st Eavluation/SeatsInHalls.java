package FirstEavluation;

public class SeatsInHalls {
    private int[][] matrix;

    public SeatsInHalls(int[][] matrix) {
        this.matrix = matrix;
    }

    public int[][] getMatrix() {
        return matrix;
    }

    public void setMatrix(int[][] matrix) {
        this.matrix = matrix;
    }

}
