package FirstEavluation;

public enum PaymentMethods {
    CREDITCARD,CASH
}
