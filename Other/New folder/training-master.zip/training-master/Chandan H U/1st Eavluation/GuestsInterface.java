package FirstEavluation;

public interface GuestsInterface {
    void SearchMovies();
}
