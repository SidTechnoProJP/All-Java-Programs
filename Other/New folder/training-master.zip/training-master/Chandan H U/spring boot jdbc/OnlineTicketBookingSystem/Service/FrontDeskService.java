package example.OnlineTicketBookingSystem.Service;

public class FrontDeskService {
}
