package example.OnlineTicketBookingSystem.Service;

public enum AccountStatus {
    ACTIVE,BLOCKED,FREEZE
}
