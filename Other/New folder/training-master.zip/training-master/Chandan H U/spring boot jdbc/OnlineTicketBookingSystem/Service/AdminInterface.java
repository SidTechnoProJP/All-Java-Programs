package example.OnlineTicketBookingSystem.Service;

public interface AdminInterface {
}
