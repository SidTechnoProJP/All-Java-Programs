package example.OnlineTicketBookingSystem.Service;

public enum ShowNames {
    MORNINGSHOW,NIGHTSHOW,SECONDSHOW,THIRDSHOW
}
