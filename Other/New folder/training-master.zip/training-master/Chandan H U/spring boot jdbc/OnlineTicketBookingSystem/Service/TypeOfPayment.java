package example.OnlineTicketBookingSystem.Service;

public enum TypeOfPayment {
    CREDITCARD,CASH
}
