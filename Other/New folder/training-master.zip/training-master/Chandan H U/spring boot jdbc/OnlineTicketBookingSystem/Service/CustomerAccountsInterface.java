package example.OnlineTicketBookingSystem.Service;

public interface CustomerAccountsInterface {
}
