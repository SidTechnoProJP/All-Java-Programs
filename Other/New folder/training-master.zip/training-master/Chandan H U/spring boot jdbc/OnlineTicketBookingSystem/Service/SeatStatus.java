package example.OnlineTicketBookingSystem.Service;

public enum SeatStatus {
    CONFIRMED,WAITING,CANCELED
}
