package example.OnlineTicketBookingSystem.Service;

public interface FrontDeskInterface {
}
