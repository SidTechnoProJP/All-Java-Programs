package example.OnlineTicketBookingSystem.Controller;

public class FrontDeskController {
}
