package com.majorEvaluation.foodApp.entity;

public class Dish {
}
