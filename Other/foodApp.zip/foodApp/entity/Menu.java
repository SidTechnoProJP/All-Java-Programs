package com.majorEvaluation.foodApp.entity;

public class Menu {
}
