package com.majorEvaluation.foodApp.entity;

public enum OtpStatus {
    DELIVERED,FAILED,VALIDATED,VALIDATION_FAILED;
}
