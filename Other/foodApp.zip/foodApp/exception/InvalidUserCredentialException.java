package com.majorEvaluation.foodApp.exception;

public class InvalidUserCredentialException extends Exception {
    public InvalidUserCredentialException(String msg) {
        super(msg);
    }
}

